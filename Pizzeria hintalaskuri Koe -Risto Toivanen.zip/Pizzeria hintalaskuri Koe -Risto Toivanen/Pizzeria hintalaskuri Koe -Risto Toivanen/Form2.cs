﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizzeria_hintalaskuri_Koe__Risto_Toivanen
{
    public partial class Form2 : Form
    {
        private Form1 form1;
        private List<double> arvot = new List<double>();
        List<NumericUpDown> numericUpDowns = new List<NumericUpDown>();
        public Form2(Form1 parentForm)
        {
            InitializeComponent();
            form1 = parentForm;
            numericUpDowns.Add(numericUpDown1);
            numericUpDowns.Add(numericUpDown2);
            numericUpDowns.Add(numericUpDown3);
            numericUpDowns.Add(numericUpDown4);
            numericUpDowns.Add(numericUpDown5);
            numericUpDowns.Add(numericUpDown6);
            numericUpDowns.Add(numericUpDown7);
            numericUpDowns.Add(numericUpDown8);
            numericUpDowns.Add(numericUpDown9);
            numericUpDowns.Add(numericUpDown10);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTallenna_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < 10; i++)
            {
                var numericUpDownControl = Controls.Find($"numericUpDown{i + 1}", true).FirstOrDefault() as NumericUpDown;

                if (numericUpDownControl != null)
                {
                    arvot.Add((double)numericUpDownControl.Value);
                    
                }
                else
                {
                    Console.WriteLine($"numericUpDown{i + 1} not found");
                }
            }
            Console.WriteLine(string.Join(" ", arvot));
            form1.paivita_hinnat(arvot);
        }
    }
}
