﻿namespace Pizzeria_hintalaskuri_Koe__Risto_Toivanen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pizza1 = new System.Windows.Forms.Label();
            this.pizza2 = new System.Windows.Forms.Label();
            this.Pizza3 = new System.Windows.Forms.Label();
            this.Pizza4 = new System.Windows.Forms.Label();
            this.Pizza5 = new System.Windows.Forms.Label();
            this.Pizza6 = new System.Windows.Forms.Label();
            this.Pizza7 = new System.Windows.Forms.Label();
            this.Pizza8 = new System.Windows.Forms.Label();
            this.Pizza9 = new System.Windows.Forms.Label();
            this.Pizza10 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.LisätäyteinfoL = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.btnMuokkaa = new System.Windows.Forms.Button();
            this.HintaL1 = new System.Windows.Forms.Label();
            this.Hinta2L = new System.Windows.Forms.Label();
            this.Hinta3L = new System.Windows.Forms.Label();
            this.Hinta5L = new System.Windows.Forms.Label();
            this.Hinta6L = new System.Windows.Forms.Label();
            this.Hinta7L = new System.Windows.Forms.Label();
            this.Hinta8L = new System.Windows.Forms.Label();
            this.Hinta9L = new System.Windows.Forms.Label();
            this.Hinta10L = new System.Windows.Forms.Label();
            this.Hinta4L = new System.Windows.Forms.Label();
            this.checkBox_Kuudeskerta = new System.Windows.Forms.CheckBox();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown22 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown23 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSumma = new System.Windows.Forms.TextBox();
            this.Hinta11L = new System.Windows.Forms.Label();
            this.Hinta12L = new System.Windows.Forms.Label();
            this.Hinta13L = new System.Windows.Forms.Label();
            this.btnNollaa = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).BeginInit();
            this.SuspendLayout();
            // 
            // Pizza1
            // 
            this.Pizza1.AutoSize = true;
            this.Pizza1.Location = new System.Drawing.Point(31, 32);
            this.Pizza1.Name = "Pizza1";
            this.Pizza1.Size = new System.Drawing.Size(57, 13);
            this.Pizza1.TabIndex = 0;
            this.Pizza1.Text = "Margherita";
            // 
            // pizza2
            // 
            this.pizza2.AutoSize = true;
            this.pizza2.Location = new System.Drawing.Point(149, 32);
            this.pizza2.Name = "pizza2";
            this.pizza2.Size = new System.Drawing.Size(55, 13);
            this.pizza2.TabIndex = 1;
            this.pizza2.Text = "Pepperoni";
            // 
            // Pizza3
            // 
            this.Pizza3.AutoSize = true;
            this.Pizza3.Location = new System.Drawing.Point(258, 32);
            this.Pizza3.Name = "Pizza3";
            this.Pizza3.Size = new System.Drawing.Size(83, 13);
            this.Pizza3.TabIndex = 3;
            this.Pizza3.Text = "Quattro Stagioni";
            // 
            // Pizza4
            // 
            this.Pizza4.AutoSize = true;
            this.Pizza4.Location = new System.Drawing.Point(394, 32);
            this.Pizza4.Name = "Pizza4";
            this.Pizza4.Size = new System.Drawing.Size(39, 13);
            this.Pizza4.TabIndex = 2;
            this.Pizza4.Text = "Havaiji";
            // 
            // Pizza5
            // 
            this.Pizza5.AutoSize = true;
            this.Pizza5.Location = new System.Drawing.Point(495, 32);
            this.Pizza5.Name = "Pizza5";
            this.Pizza5.Size = new System.Drawing.Size(43, 13);
            this.Pizza5.TabIndex = 7;
            this.Pizza5.Text = "Diavola";
            // 
            // Pizza6
            // 
            this.Pizza6.AutoSize = true;
            this.Pizza6.Location = new System.Drawing.Point(21, 200);
            this.Pizza6.Name = "Pizza6";
            this.Pizza6.Size = new System.Drawing.Size(67, 13);
            this.Pizza6.TabIndex = 6;
            this.Pizza6.Text = "Vegetariana ";
            // 
            // Pizza7
            // 
            this.Pizza7.AutoSize = true;
            this.Pizza7.Location = new System.Drawing.Point(140, 200);
            this.Pizza7.Name = "Pizza7";
            this.Pizza7.Size = new System.Drawing.Size(65, 13);
            this.Pizza7.TabIndex = 5;
            this.Pizza7.Text = "Capricciosa ";
            // 
            // Pizza8
            // 
            this.Pizza8.AutoSize = true;
            this.Pizza8.Location = new System.Drawing.Point(264, 200);
            this.Pizza8.Name = "Pizza8";
            this.Pizza8.Size = new System.Drawing.Size(71, 13);
            this.Pizza8.TabIndex = 4;
            this.Pizza8.Text = "Frutti di Mare ";
            // 
            // Pizza9
            // 
            this.Pizza9.AutoSize = true;
            this.Pizza9.Location = new System.Drawing.Point(372, 200);
            this.Pizza9.Name = "Pizza9";
            this.Pizza9.Size = new System.Drawing.Size(71, 13);
            this.Pizza9.TabIndex = 8;
            this.Pizza9.Text = "BBQ Chicken";
            // 
            // Pizza10
            // 
            this.Pizza10.AutoSize = true;
            this.Pizza10.Location = new System.Drawing.Point(490, 200);
            this.Pizza10.Name = "Pizza10";
            this.Pizza10.Size = new System.Drawing.Size(54, 13);
            this.Pizza10.TabIndex = 9;
            this.Pizza10.Text = "Prosciutto";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(80, 68);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(40, 22);
            this.numericUpDown1.TabIndex = 10;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown2.Location = new System.Drawing.Point(201, 68);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(43, 22);
            this.numericUpDown2.TabIndex = 11;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown3.Location = new System.Drawing.Point(325, 67);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(41, 22);
            this.numericUpDown3.TabIndex = 12;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown4.Location = new System.Drawing.Point(433, 67);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(43, 22);
            this.numericUpDown4.TabIndex = 13;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown5.Location = new System.Drawing.Point(544, 69);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(44, 22);
            this.numericUpDown5.TabIndex = 14;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown6.Location = new System.Drawing.Point(80, 240);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(40, 22);
            this.numericUpDown6.TabIndex = 15;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown7.Location = new System.Drawing.Point(201, 240);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(43, 22);
            this.numericUpDown7.TabIndex = 16;
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown8.Location = new System.Drawing.Point(325, 240);
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(41, 22);
            this.numericUpDown8.TabIndex = 17;
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown9.Location = new System.Drawing.Point(433, 240);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(43, 22);
            this.numericUpDown9.TabIndex = 18;
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown10.Location = new System.Drawing.Point(544, 240);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(44, 22);
            this.numericUpDown10.TabIndex = 19;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 68);
            this.textBox1.MaxLength = 2;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 20);
            this.textBox1.TabIndex = 20;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(150, 67);
            this.textBox2.MaxLength = 2;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(45, 20);
            this.textBox2.TabIndex = 21;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(274, 68);
            this.textBox3.MaxLength = 2;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(45, 20);
            this.textBox3.TabIndex = 22;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(382, 68);
            this.textBox4.MaxLength = 2;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(45, 20);
            this.textBox4.TabIndex = 23;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(493, 69);
            this.textBox5.MaxLength = 2;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(45, 20);
            this.textBox5.TabIndex = 24;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(29, 240);
            this.textBox6.MaxLength = 2;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(45, 20);
            this.textBox6.TabIndex = 25;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(150, 240);
            this.textBox7.MaxLength = 2;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(45, 20);
            this.textBox7.TabIndex = 26;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(274, 240);
            this.textBox8.MaxLength = 2;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(45, 20);
            this.textBox8.TabIndex = 27;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(382, 240);
            this.textBox9.MaxLength = 2;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(45, 20);
            this.textBox9.TabIndex = 28;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(493, 240);
            this.textBox10.MaxLength = 2;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 20);
            this.textBox10.TabIndex = 29;
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Location = new System.Drawing.Point(80, 94);
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(40, 20);
            this.numericUpDown11.TabIndex = 30;
            this.numericUpDown11.Tag = "LisaTayte";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label11.Location = new System.Drawing.Point(19, 99);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 15);
            this.label11.TabIndex = 31;
            this.label11.Text = "Lisätäyte";
            // 
            // LisätäyteinfoL
            // 
            this.LisätäyteinfoL.AutoSize = true;
            this.LisätäyteinfoL.Location = new System.Drawing.Point(13, 425);
            this.LisätäyteinfoL.Name = "LisätäyteinfoL";
            this.LisätäyteinfoL.Size = new System.Drawing.Size(136, 13);
            this.LisätäyteinfoL.TabIndex = 32;
            this.LisätäyteinfoL.Text = "Lisätäytteiden hinta aina 2€";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label12.Location = new System.Drawing.Point(140, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 15);
            this.label12.TabIndex = 33;
            this.label12.Text = "Lisätäyte";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label13.Location = new System.Drawing.Point(264, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 15);
            this.label13.TabIndex = 34;
            this.label13.Text = "Lisätäyte";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label14.Location = new System.Drawing.Point(372, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 35;
            this.label14.Text = "Lisätäyte";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label15.Location = new System.Drawing.Point(490, 99);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 15);
            this.label15.TabIndex = 36;
            this.label15.Text = "Lisätäyte";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label16.Location = new System.Drawing.Point(19, 266);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 15);
            this.label16.TabIndex = 37;
            this.label16.Text = "Lisätäyte";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label17.Location = new System.Drawing.Point(140, 266);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 15);
            this.label17.TabIndex = 38;
            this.label17.Text = "Lisätäyte";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label18.Location = new System.Drawing.Point(264, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 15);
            this.label18.TabIndex = 39;
            this.label18.Text = "Lisätäyte";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label19.Location = new System.Drawing.Point(372, 266);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 15);
            this.label19.TabIndex = 40;
            this.label19.Text = "Lisätäyte";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label20.Location = new System.Drawing.Point(483, 266);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 15);
            this.label20.TabIndex = 41;
            this.label20.Text = "Lisätäyte";
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.Location = new System.Drawing.Point(201, 99);
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(43, 20);
            this.numericUpDown12.TabIndex = 42;
            this.numericUpDown12.Tag = "LisaTayte";
            // 
            // numericUpDown13
            // 
            this.numericUpDown13.Location = new System.Drawing.Point(325, 99);
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown13.TabIndex = 43;
            this.numericUpDown13.Tag = "LisaTayte";
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.Location = new System.Drawing.Point(433, 99);
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(43, 20);
            this.numericUpDown14.TabIndex = 44;
            this.numericUpDown14.Tag = "LisaTayte";
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.Location = new System.Drawing.Point(544, 99);
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(44, 20);
            this.numericUpDown15.TabIndex = 45;
            this.numericUpDown15.Tag = "LisaTayte";
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.Location = new System.Drawing.Point(80, 266);
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(40, 20);
            this.numericUpDown16.TabIndex = 46;
            this.numericUpDown16.Tag = "LisaTayte";
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.Location = new System.Drawing.Point(201, 266);
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(43, 20);
            this.numericUpDown17.TabIndex = 47;
            this.numericUpDown17.Tag = "LisaTayte";
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.Location = new System.Drawing.Point(325, 266);
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown18.TabIndex = 48;
            this.numericUpDown18.Tag = "LisaTayte";
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.Location = new System.Drawing.Point(433, 266);
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(44, 20);
            this.numericUpDown19.TabIndex = 49;
            this.numericUpDown19.Tag = "LisaTayte";
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.Location = new System.Drawing.Point(544, 266);
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(44, 20);
            this.numericUpDown20.TabIndex = 50;
            this.numericUpDown20.Tag = "LisaTayte";
            // 
            // btnMuokkaa
            // 
            this.btnMuokkaa.Location = new System.Drawing.Point(649, 2);
            this.btnMuokkaa.Name = "btnMuokkaa";
            this.btnMuokkaa.Size = new System.Drawing.Size(150, 31);
            this.btnMuokkaa.TabIndex = 51;
            this.btnMuokkaa.Text = " Muokkaa hintoja";
            this.btnMuokkaa.UseVisualStyleBackColor = true;
            this.btnMuokkaa.Click += new System.EventHandler(this.btnMuokkaa_Click);
            // 
            // HintaL1
            // 
            this.HintaL1.AutoSize = true;
            this.HintaL1.Location = new System.Drawing.Point(87, 32);
            this.HintaL1.Name = "HintaL1";
            this.HintaL1.Size = new System.Drawing.Size(25, 13);
            this.HintaL1.TabIndex = 52;
            this.HintaL1.Tag = "Hinta";
            this.HintaL1.Text = "10€";
            // 
            // Hinta2L
            // 
            this.Hinta2L.AutoSize = true;
            this.Hinta2L.Location = new System.Drawing.Point(202, 32);
            this.Hinta2L.Name = "Hinta2L";
            this.Hinta2L.Size = new System.Drawing.Size(25, 13);
            this.Hinta2L.TabIndex = 53;
            this.Hinta2L.Tag = "Hinta";
            this.Hinta2L.Text = "12€";
            // 
            // Hinta3L
            // 
            this.Hinta3L.AutoSize = true;
            this.Hinta3L.Location = new System.Drawing.Point(336, 32);
            this.Hinta3L.Name = "Hinta3L";
            this.Hinta3L.Size = new System.Drawing.Size(25, 13);
            this.Hinta3L.TabIndex = 54;
            this.Hinta3L.Tag = "Hinta";
            this.Hinta3L.Text = "13€";
            // 
            // Hinta5L
            // 
            this.Hinta5L.AutoSize = true;
            this.Hinta5L.Location = new System.Drawing.Point(544, 32);
            this.Hinta5L.Name = "Hinta5L";
            this.Hinta5L.Size = new System.Drawing.Size(25, 13);
            this.Hinta5L.TabIndex = 55;
            this.Hinta5L.Tag = "Hinta";
            this.Hinta5L.Text = "12€";
            // 
            // Hinta6L
            // 
            this.Hinta6L.AutoSize = true;
            this.Hinta6L.Location = new System.Drawing.Point(87, 200);
            this.Hinta6L.Name = "Hinta6L";
            this.Hinta6L.Size = new System.Drawing.Size(25, 13);
            this.Hinta6L.TabIndex = 56;
            this.Hinta6L.Tag = "Hinta";
            this.Hinta6L.Text = "11€";
            // 
            // Hinta7L
            // 
            this.Hinta7L.AutoSize = true;
            this.Hinta7L.Location = new System.Drawing.Point(202, 200);
            this.Hinta7L.Name = "Hinta7L";
            this.Hinta7L.Size = new System.Drawing.Size(25, 13);
            this.Hinta7L.TabIndex = 57;
            this.Hinta7L.Tag = "Hinta";
            this.Hinta7L.Text = "13€";
            // 
            // Hinta8L
            // 
            this.Hinta8L.AutoSize = true;
            this.Hinta8L.Location = new System.Drawing.Point(336, 200);
            this.Hinta8L.Name = "Hinta8L";
            this.Hinta8L.Size = new System.Drawing.Size(25, 13);
            this.Hinta8L.TabIndex = 58;
            this.Hinta8L.Tag = "Hinta";
            this.Hinta8L.Text = "14€";
            // 
            // Hinta9L
            // 
            this.Hinta9L.AutoSize = true;
            this.Hinta9L.Location = new System.Drawing.Point(440, 200);
            this.Hinta9L.Name = "Hinta9L";
            this.Hinta9L.Size = new System.Drawing.Size(25, 13);
            this.Hinta9L.TabIndex = 59;
            this.Hinta9L.Tag = "Hinta";
            this.Hinta9L.Text = "12€";
            // 
            // Hinta10L
            // 
            this.Hinta10L.AutoSize = true;
            this.Hinta10L.Location = new System.Drawing.Point(544, 200);
            this.Hinta10L.Name = "Hinta10L";
            this.Hinta10L.Size = new System.Drawing.Size(25, 13);
            this.Hinta10L.TabIndex = 60;
            this.Hinta10L.Tag = "Hinta";
            this.Hinta10L.Text = "11€";
            // 
            // Hinta4L
            // 
            this.Hinta4L.AutoSize = true;
            this.Hinta4L.Location = new System.Drawing.Point(430, 32);
            this.Hinta4L.Name = "Hinta4L";
            this.Hinta4L.Size = new System.Drawing.Size(25, 13);
            this.Hinta4L.TabIndex = 61;
            this.Hinta4L.Tag = "Hinta";
            this.Hinta4L.Text = "11€";
            // 
            // checkBox_Kuudeskerta
            // 
            this.checkBox_Kuudeskerta.AutoSize = true;
            this.checkBox_Kuudeskerta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Kuudeskerta.Location = new System.Drawing.Point(544, 417);
            this.checkBox_Kuudeskerta.Name = "checkBox_Kuudeskerta";
            this.checkBox_Kuudeskerta.Size = new System.Drawing.Size(130, 19);
            this.checkBox_Kuudeskerta.TabIndex = 63;
            this.checkBox_Kuudeskerta.Text = "Kuudes Pitsa -50%";
            this.checkBox_Kuudeskerta.UseVisualStyleBackColor = true;
            // 
            // numericUpDown21
            // 
            this.numericUpDown21.Location = new System.Drawing.Point(189, 418);
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.Size = new System.Drawing.Size(38, 20);
            this.numericUpDown21.TabIndex = 64;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.7F);
            this.label1.Location = new System.Drawing.Point(170, 399);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 15);
            this.label1.TabIndex = 65;
            this.label1.Text = "0,5L kola";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.7F);
            this.label2.Location = new System.Drawing.Point(264, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 66;
            this.label2.Text = "1,5L kola";
            // 
            // numericUpDown22
            // 
            this.numericUpDown22.Location = new System.Drawing.Point(274, 417);
            this.numericUpDown22.Name = "numericUpDown22";
            this.numericUpDown22.Size = new System.Drawing.Size(38, 20);
            this.numericUpDown22.TabIndex = 67;
            // 
            // numericUpDown23
            // 
            this.numericUpDown23.Location = new System.Drawing.Point(355, 418);
            this.numericUpDown23.Name = "numericUpDown23";
            this.numericUpDown23.Size = new System.Drawing.Size(38, 20);
            this.numericUpDown23.TabIndex = 69;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.7F);
            this.label3.Location = new System.Drawing.Point(352, 400);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 68;
            this.label3.Text = "Kahvi";
            // 
            // txtSumma
            // 
            this.txtSumma.Location = new System.Drawing.Point(688, 417);
            this.txtSumma.Name = "txtSumma";
            this.txtSumma.ReadOnly = true;
            this.txtSumma.Size = new System.Drawing.Size(100, 20);
            this.txtSumma.TabIndex = 70;
            this.txtSumma.Tag = "Summa";
            // 
            // Hinta11L
            // 
            this.Hinta11L.AutoSize = true;
            this.Hinta11L.Location = new System.Drawing.Point(167, 421);
            this.Hinta11L.Name = "Hinta11L";
            this.Hinta11L.Size = new System.Drawing.Size(19, 13);
            this.Hinta11L.TabIndex = 71;
            this.Hinta11L.Tag = "Hinta";
            this.Hinta11L.Text = "2€";
            // 
            // Hinta12L
            // 
            this.Hinta12L.AutoSize = true;
            this.Hinta12L.Location = new System.Drawing.Point(249, 421);
            this.Hinta12L.Name = "Hinta12L";
            this.Hinta12L.Size = new System.Drawing.Size(19, 13);
            this.Hinta12L.TabIndex = 72;
            this.Hinta12L.Tag = "Hinta";
            this.Hinta12L.Text = "4€";
            // 
            // Hinta13L
            // 
            this.Hinta13L.AutoSize = true;
            this.Hinta13L.Location = new System.Drawing.Point(318, 421);
            this.Hinta13L.Name = "Hinta13L";
            this.Hinta13L.Size = new System.Drawing.Size(34, 13);
            this.Hinta13L.TabIndex = 73;
            this.Hinta13L.Tag = "Hinta";
            this.Hinta13L.Text = "2,50€";
            // 
            // btnNollaa
            // 
            this.btnNollaa.Location = new System.Drawing.Point(724, 39);
            this.btnNollaa.Name = "btnNollaa";
            this.btnNollaa.Size = new System.Drawing.Size(75, 23);
            this.btnNollaa.TabIndex = 74;
            this.btnNollaa.Text = "Nollaa";
            this.btnNollaa.UseVisualStyleBackColor = true;
            this.btnNollaa.Click += new System.EventHandler(this.btnNollaa_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNollaa);
            this.Controls.Add(this.Hinta13L);
            this.Controls.Add(this.Hinta12L);
            this.Controls.Add(this.Hinta11L);
            this.Controls.Add(this.txtSumma);
            this.Controls.Add(this.numericUpDown23);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDown22);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown21);
            this.Controls.Add(this.checkBox_Kuudeskerta);
            this.Controls.Add(this.Hinta4L);
            this.Controls.Add(this.Hinta10L);
            this.Controls.Add(this.Hinta9L);
            this.Controls.Add(this.Hinta8L);
            this.Controls.Add(this.Hinta7L);
            this.Controls.Add(this.Hinta6L);
            this.Controls.Add(this.Hinta5L);
            this.Controls.Add(this.Hinta3L);
            this.Controls.Add(this.Hinta2L);
            this.Controls.Add(this.HintaL1);
            this.Controls.Add(this.btnMuokkaa);
            this.Controls.Add(this.numericUpDown20);
            this.Controls.Add(this.numericUpDown19);
            this.Controls.Add(this.numericUpDown18);
            this.Controls.Add(this.numericUpDown17);
            this.Controls.Add(this.numericUpDown16);
            this.Controls.Add(this.numericUpDown15);
            this.Controls.Add(this.numericUpDown14);
            this.Controls.Add(this.numericUpDown13);
            this.Controls.Add(this.numericUpDown12);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.LisätäyteinfoL);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.numericUpDown11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.numericUpDown10);
            this.Controls.Add(this.numericUpDown9);
            this.Controls.Add(this.numericUpDown8);
            this.Controls.Add(this.numericUpDown7);
            this.Controls.Add(this.numericUpDown6);
            this.Controls.Add(this.numericUpDown5);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.Pizza10);
            this.Controls.Add(this.Pizza9);
            this.Controls.Add(this.Pizza5);
            this.Controls.Add(this.Pizza6);
            this.Controls.Add(this.Pizza7);
            this.Controls.Add(this.Pizza8);
            this.Controls.Add(this.Pizza3);
            this.Controls.Add(this.Pizza4);
            this.Controls.Add(this.pizza2);
            this.Controls.Add(this.Pizza1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Pizza1;
        private System.Windows.Forms.Label pizza2;
        private System.Windows.Forms.Label Pizza3;
        private System.Windows.Forms.Label Pizza4;
        private System.Windows.Forms.Label Pizza5;
        private System.Windows.Forms.Label Pizza6;
        private System.Windows.Forms.Label Pizza7;
        private System.Windows.Forms.Label Pizza8;
        private System.Windows.Forms.Label Pizza9;
        private System.Windows.Forms.Label Pizza10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label LisätäyteinfoL;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.Button btnMuokkaa;
        private System.Windows.Forms.Label HintaL1;
        private System.Windows.Forms.Label Hinta2L;
        private System.Windows.Forms.Label Hinta3L;
        private System.Windows.Forms.Label Hinta5L;
        private System.Windows.Forms.Label Hinta6L;
        private System.Windows.Forms.Label Hinta7L;
        private System.Windows.Forms.Label Hinta8L;
        private System.Windows.Forms.Label Hinta9L;
        private System.Windows.Forms.Label Hinta10L;
        private System.Windows.Forms.Label Hinta4L;
        private System.Windows.Forms.CheckBox checkBox_Kuudeskerta;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown22;
        private System.Windows.Forms.NumericUpDown numericUpDown23;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSumma;
        private System.Windows.Forms.Label Hinta11L;
        private System.Windows.Forms.Label Hinta12L;
        private System.Windows.Forms.Label Hinta13L;
        private System.Windows.Forms.Button btnNollaa;
    }
}

