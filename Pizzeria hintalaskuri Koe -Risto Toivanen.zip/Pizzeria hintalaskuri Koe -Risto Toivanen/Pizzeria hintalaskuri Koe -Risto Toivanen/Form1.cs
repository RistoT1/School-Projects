﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizzeria_hintalaskuri_Koe__Risto_Toivanen
{
    public partial class Form1 : Form
    {
        Dictionary<TextBox, NumericUpDown> arvoparitus = new Dictionary<TextBox, NumericUpDown>();
        Dictionary<NumericUpDown, Label> Hinnat = new Dictionary<NumericUpDown, Label>();
        List<(NumericUpDown, NumericUpDown)> updownpairs = new List<(NumericUpDown, NumericUpDown)>();
        List<Label> LabelsHinnat = new List<Label>();
        public Form1()
        {
            InitializeComponent();
            arvoparitus.Add(textBox1, numericUpDown1);
            arvoparitus.Add(textBox2, numericUpDown2);
            arvoparitus.Add(textBox3, numericUpDown3);
            arvoparitus.Add(textBox4, numericUpDown4);
            arvoparitus.Add(textBox5, numericUpDown5);
            arvoparitus.Add(textBox6, numericUpDown6);
            arvoparitus.Add(textBox7, numericUpDown7);
            arvoparitus.Add(textBox8, numericUpDown8);
            arvoparitus.Add(textBox9, numericUpDown9);
            arvoparitus.Add(textBox10, numericUpDown10);

            for (int i = 1; i <= 10; i++)
            {
                updownpairs.Add((Controls.Find($"numericUpDown{i}", true).FirstOrDefault() as NumericUpDown,
                                 Controls.Find($"numericUpDown{i + 10}", true).FirstOrDefault() as NumericUpDown));
            }
            LabelsHinnat.Add(HintaL1);
            LabelsHinnat.Add(Hinta2L);
            LabelsHinnat.Add(Hinta3L);
            LabelsHinnat.Add(Hinta4L);
            LabelsHinnat.Add(Hinta5L); 
            LabelsHinnat.Add(Hinta6L);
            LabelsHinnat.Add(Hinta7L);
            LabelsHinnat.Add(Hinta8L);
            LabelsHinnat.Add(Hinta9L);
            LabelsHinnat.Add(Hinta10L);

            Hinnat.Add(numericUpDown1, HintaL1);
            Hinnat.Add(numericUpDown2, Hinta2L);
            Hinnat.Add(numericUpDown3, Hinta3L);
            Hinnat.Add(numericUpDown4, Hinta4L);
            Hinnat.Add(numericUpDown5, Hinta5L);
            Hinnat.Add(numericUpDown6, Hinta6L);
            Hinnat.Add(numericUpDown7, Hinta7L);
            Hinnat.Add(numericUpDown8, Hinta8L);
            Hinnat.Add(numericUpDown9, Hinta9L);
            Hinnat.Add(numericUpDown10, Hinta10L);
            Hinnat.Add(numericUpDown21, Hinta11L);
            Hinnat.Add(numericUpDown22, Hinta12L);
            Hinnat.Add(numericUpDown23, Hinta13L);


            foreach (Control control in this.Controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.TextChanged += textbox_pitsaValue;
                    textBox.Leave += Textbox_clear;
                }
                if (control is NumericUpDown numeric)
                {
                    numeric.ValueChanged += pitsaValue;
                }
            }
            this.Click += Form1_Click;
            checkBox_Kuudeskerta.CheckedChanged += pitsaValue;
        }
        private void pitsaValue(object sender, EventArgs e)
        {


            if (sender is NumericUpDown numeric || sender is CheckBox)
            {

                double summa = 0;
                int pitsalaskuri = 0;
                double hintaParsed;
                foreach (var pari in Hinnat)
                {
                    NumericUpDown currentNumeric = pari.Key;
                    Label currentLabel = pari.Value;

                    string text = currentLabel.Text.Replace("€", "").Trim();
                    Console.WriteLine(text);
                    bool onnistui = double.TryParse(text, out hintaParsed);
                    if (onnistui)
                    {
                        Console.WriteLine("onnistui " + hintaParsed.ToString());

                        int pizzaCount = (int)currentNumeric.Value;

                        for (int i = 0; i < pizzaCount; i++)
                        {
                            if (hintaParsed >= 10)
                            {
                                pitsalaskuri++;

                                if (pitsalaskuri == 6 && checkBox_Kuudeskerta.Checked)
                                {
                                    summa += hintaParsed / 2;
                                    pitsalaskuri = 0;
                                }
                                else
                                {
                                    summa += hintaParsed;
                                }
                            }
                            else
                            {
                                summa += hintaParsed;
                            }
                        }

                        Console.WriteLine("Summa: " + summa.ToString());
                    }
                    else
                    {
                        Console.WriteLine("epäonnistui");
                    }

                }
                foreach (var (numeric1, numeric2) in updownpairs)
                {
                    if (numeric1.Value > 0 && numeric2.Value > 0  && numeric2.Tag != null && numeric2.Tag.ToString() == "LisaTayte")
                    {
                        summa += 2 * (int)numeric2.Value;
                    }     
                }
                Console.WriteLine(summa);
                txtSumma.Text = summa.ToString("F2") + "€";
            }
        }

        private void textbox_pitsaValue(object sender, EventArgs e)
        {

            if (sender is TextBox textBox) // jos tapahtuma tuli textboxista 
            {
                int arvo;
                bool onnistui = int.TryParse(textBox.Text, out arvo);
                //tarkistaa onko positiivinen arvo ja parsetus onnistunut
                if (textBox.Tag == null)
                {
                    if (arvo >= 0 && onnistui)
                    {
                        //tarkistaa sisältyykö textboxi arvoparitus "listaan/directoryyn" 
                        // Ja onko sillä paria jonka arvo voidaan muuttaa.
                        if (arvoparitus.ContainsKey(textBox))
                        {
                            //Asetetaan numericUpDownin arvo textBoxin arvon mukaisesti
                            arvoparitus[textBox].Value = arvo;
                        }
                    }
                    else
                    {
                        textBox.Clear();
                    }
                }
            }
        }
        private void Textbox_clear(object sender, EventArgs e)
        {
            if (sender is TextBox textBox && textBox.Tag == null)
            {
                textBox.Clear();
            }

        }
        public void paivita_hinnat(List<double> arvot)
        {
            for(int i = 0; i < arvot.Count && i < LabelsHinnat.Count; i++)
            {   

                
                LabelsHinnat[i].Text = arvot[i].ToString("F2") +"€";  
                
            }
        }
        private void Form1_Click(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void btnNollaa_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is NumericUpDown numeric)
                {
                    numeric.Value = 0;
                }
            }
            txtSumma.Text = "0€";
        }

        private void btnMuokkaa_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(this);
            form2.Show();

        }
    }
}
