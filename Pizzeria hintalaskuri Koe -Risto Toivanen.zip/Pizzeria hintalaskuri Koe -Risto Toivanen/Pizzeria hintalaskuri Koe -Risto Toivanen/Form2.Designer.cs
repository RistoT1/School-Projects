﻿namespace Pizzeria_hintalaskuri_Koe__Risto_Toivanen
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pizza5 = new System.Windows.Forms.Label();
            this.Pizza3 = new System.Windows.Forms.Label();
            this.Pizza4 = new System.Windows.Forms.Label();
            this.pizza2 = new System.Windows.Forms.Label();
            this.Pizza1 = new System.Windows.Forms.Label();
            this.Pizza10 = new System.Windows.Forms.Label();
            this.Pizza9 = new System.Windows.Forms.Label();
            this.Pizza6 = new System.Windows.Forms.Label();
            this.Pizza7 = new System.Windows.Forms.Label();
            this.Pizza8 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnTallenna = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            this.SuspendLayout();
            // 
            // Pizza5
            // 
            this.Pizza5.AutoSize = true;
            this.Pizza5.Location = new System.Drawing.Point(500, 54);
            this.Pizza5.Name = "Pizza5";
            this.Pizza5.Size = new System.Drawing.Size(43, 13);
            this.Pizza5.TabIndex = 66;
            this.Pizza5.Text = "Diavola";
            // 
            // Pizza3
            // 
            this.Pizza3.AutoSize = true;
            this.Pizza3.Location = new System.Drawing.Point(263, 54);
            this.Pizza3.Name = "Pizza3";
            this.Pizza3.Size = new System.Drawing.Size(83, 13);
            this.Pizza3.TabIndex = 65;
            this.Pizza3.Text = "Quattro Stagioni";
            // 
            // Pizza4
            // 
            this.Pizza4.AutoSize = true;
            this.Pizza4.Location = new System.Drawing.Point(399, 54);
            this.Pizza4.Name = "Pizza4";
            this.Pizza4.Size = new System.Drawing.Size(39, 13);
            this.Pizza4.TabIndex = 64;
            this.Pizza4.Text = "Havaiji";
            // 
            // pizza2
            // 
            this.pizza2.AutoSize = true;
            this.pizza2.Location = new System.Drawing.Point(154, 54);
            this.pizza2.Name = "pizza2";
            this.pizza2.Size = new System.Drawing.Size(55, 13);
            this.pizza2.TabIndex = 63;
            this.pizza2.Text = "Pepperoni";
            // 
            // Pizza1
            // 
            this.Pizza1.AutoSize = true;
            this.Pizza1.Location = new System.Drawing.Point(36, 54);
            this.Pizza1.Name = "Pizza1";
            this.Pizza1.Size = new System.Drawing.Size(57, 13);
            this.Pizza1.TabIndex = 62;
            this.Pizza1.Text = "Margherita";
            // 
            // Pizza10
            // 
            this.Pizza10.AutoSize = true;
            this.Pizza10.Location = new System.Drawing.Point(498, 127);
            this.Pizza10.Name = "Pizza10";
            this.Pizza10.Size = new System.Drawing.Size(54, 13);
            this.Pizza10.TabIndex = 71;
            this.Pizza10.Text = "Prosciutto";
            // 
            // Pizza9
            // 
            this.Pizza9.AutoSize = true;
            this.Pizza9.Location = new System.Drawing.Point(387, 127);
            this.Pizza9.Name = "Pizza9";
            this.Pizza9.Size = new System.Drawing.Size(71, 13);
            this.Pizza9.TabIndex = 70;
            this.Pizza9.Text = "BBQ Chicken";
            // 
            // Pizza6
            // 
            this.Pizza6.AutoSize = true;
            this.Pizza6.Location = new System.Drawing.Point(36, 127);
            this.Pizza6.Name = "Pizza6";
            this.Pizza6.Size = new System.Drawing.Size(67, 13);
            this.Pizza6.TabIndex = 69;
            this.Pizza6.Text = "Vegetariana ";
            // 
            // Pizza7
            // 
            this.Pizza7.AutoSize = true;
            this.Pizza7.Location = new System.Drawing.Point(155, 127);
            this.Pizza7.Name = "Pizza7";
            this.Pizza7.Size = new System.Drawing.Size(65, 13);
            this.Pizza7.TabIndex = 68;
            this.Pizza7.Text = "Capricciosa ";
            // 
            // Pizza8
            // 
            this.Pizza8.AutoSize = true;
            this.Pizza8.Location = new System.Drawing.Point(273, 127);
            this.Pizza8.Name = "Pizza8";
            this.Pizza8.Size = new System.Drawing.Size(71, 13);
            this.Pizza8.TabIndex = 67;
            this.Pizza8.Text = "Frutti di Mare ";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 2;
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown1.Location = new System.Drawing.Point(39, 84);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown1.TabIndex = 72;
            this.numericUpDown1.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 2;
            this.numericUpDown2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown2.Location = new System.Drawing.Point(155, 84);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown2.TabIndex = 73;
            this.numericUpDown2.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DecimalPlaces = 2;
            this.numericUpDown3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown3.Location = new System.Drawing.Point(282, 84);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown3.TabIndex = 74;
            this.numericUpDown3.Value = new decimal(new int[] {
            13,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 2;
            this.numericUpDown4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown4.Location = new System.Drawing.Point(394, 84);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown4.TabIndex = 75;
            this.numericUpDown4.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.DecimalPlaces = 2;
            this.numericUpDown5.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown5.Location = new System.Drawing.Point(500, 84);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown5.TabIndex = 76;
            this.numericUpDown5.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.DecimalPlaces = 2;
            this.numericUpDown6.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown6.Location = new System.Drawing.Point(39, 164);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown6.TabIndex = 77;
            this.numericUpDown6.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.DecimalPlaces = 2;
            this.numericUpDown7.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown7.Location = new System.Drawing.Point(155, 164);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown7.TabIndex = 78;
            this.numericUpDown7.Value = new decimal(new int[] {
            13,
            0,
            0,
            0});
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.DecimalPlaces = 2;
            this.numericUpDown8.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown8.Location = new System.Drawing.Point(282, 164);
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown8.TabIndex = 79;
            this.numericUpDown8.Value = new decimal(new int[] {
            14,
            0,
            0,
            0});
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.DecimalPlaces = 2;
            this.numericUpDown9.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown9.Location = new System.Drawing.Point(394, 164);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown9.TabIndex = 80;
            this.numericUpDown9.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.DecimalPlaces = 2;
            this.numericUpDown10.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown10.Location = new System.Drawing.Point(500, 164);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(54, 20);
            this.numericUpDown10.TabIndex = 81;
            this.numericUpDown10.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(682, 393);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 45);
            this.button1.TabIndex = 82;
            this.button1.Text = "Sulje ikkuna";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(155, 401);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 37);
            this.button2.TabIndex = 83;
            this.button2.Text = "Uusi Pitsa";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(39, 401);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 37);
            this.button3.TabIndex = 84;
            this.button3.Text = "Poista pitsa";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnTallenna
            // 
            this.btnTallenna.Location = new System.Drawing.Point(585, 415);
            this.btnTallenna.Name = "btnTallenna";
            this.btnTallenna.Size = new System.Drawing.Size(75, 23);
            this.btnTallenna.TabIndex = 85;
            this.btnTallenna.Text = "tallenna";
            this.btnTallenna.UseVisualStyleBackColor = true;
            this.btnTallenna.Click += new System.EventHandler(this.btnTallenna_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTallenna);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericUpDown10);
            this.Controls.Add(this.numericUpDown9);
            this.Controls.Add(this.numericUpDown8);
            this.Controls.Add(this.numericUpDown7);
            this.Controls.Add(this.numericUpDown6);
            this.Controls.Add(this.numericUpDown5);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.Pizza10);
            this.Controls.Add(this.Pizza9);
            this.Controls.Add(this.Pizza6);
            this.Controls.Add(this.Pizza7);
            this.Controls.Add(this.Pizza8);
            this.Controls.Add(this.Pizza5);
            this.Controls.Add(this.Pizza3);
            this.Controls.Add(this.Pizza4);
            this.Controls.Add(this.pizza2);
            this.Controls.Add(this.Pizza1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Pizza5;
        private System.Windows.Forms.Label Pizza3;
        private System.Windows.Forms.Label Pizza4;
        private System.Windows.Forms.Label pizza2;
        private System.Windows.Forms.Label Pizza1;
        private System.Windows.Forms.Label Pizza10;
        private System.Windows.Forms.Label Pizza9;
        private System.Windows.Forms.Label Pizza6;
        private System.Windows.Forms.Label Pizza7;
        private System.Windows.Forms.Label Pizza8;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnTallenna;
    }
}