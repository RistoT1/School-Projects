﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kaksiformia_käyttäjät
{
    public partial class Form2 : Form
    {
        public Form2(string nimi)
        {
            InitializeComponent();
            this.Text = nimi;
            ruokaaineet[] ruokaaine = new ruokaaineet[]
            {
                    new ruokaaineet {nimi = "peruna",kalorit = "75", maara = "1"},
                    new ruokaaineet {nimi = "riisi",kalorit = "130", maara = "0"},
                    new ruokaaineet {nimi = "pasta",kalorit = "131", maara = "0"}
            };
            dataGridView1.DataSource = ruokaaine;

            dataGridView1.Columns.Add("kokonaisjoulet", "Kokonaisjoulet");
            dataGridView1.Columns.Add("kokonaiskalori", "Kokonaiskalorit");
            dataGridView1.Columns["kokonaiskalori"].ReadOnly = true;
            dataGridView1.Columns["nimi"].ReadOnly = true;
            dataGridView1.Columns["maara"].ReadOnly = false;
            dataGridView1.Columns["kalorit"].ReadOnly = true;


            dataGridView1.CellValueChanged += DataGridView1_CellValueChanged;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns["Nimi"].HeaderText = "Ruoka-aine";
            dataGridView1.Columns["Kalorit"].HeaderText = "Kalorit/100g";
            dataGridView1.Columns["Maara"].HeaderText = "Määrä (g)";
        }

        private void DataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // Check if the cell is valid and belongs to the "maara" column
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count &&
                e.ColumnIndex >= 0 && e.ColumnIndex < dataGridView1.Columns.Count &&
                dataGridView1.Columns[e.ColumnIndex].Name == "maara")
            {
                // Get the cell value
                var cellValue = dataGridView1[e.ColumnIndex, e.RowIndex].Value;

                // Check if the value is null or empty
                if (cellValue == null || string.IsNullOrEmpty(cellValue.ToString()))
                {
                    // Set an error message and cancel the edit
                    dataGridView1[e.ColumnIndex, e.RowIndex].Value = 0;
                    return;
                }

                // Try to parse the value as an integer
                if (!int.TryParse(cellValue.ToString(), out int parsedValue))
                {
                    // Set an error message and cancel the edit
                    dataGridView1[e.ColumnIndex, e.RowIndex].Value = 0;
                    return;
                }

                // Check if the value is negative
                if (parsedValue < 0)
                {
                    // Set an error message and cancel the edit
                    dataGridView1[e.ColumnIndex, e.RowIndex].Value = 0;
                    return;
                }

                // Clear any previous error message if the value is valid
                dataGridView1.Rows[e.RowIndex].ErrorText = string.Empty;
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double TaulukonKalorit =0;
            double TaulukonJoulet =0;
            ruokaaineet RuokaAine = new ruokaaineet();
            for (int rivi = 0; rivi < dataGridView1.RowCount; rivi++)
            {
                var maaraValue = dataGridView1.Rows[rivi].Cells["maara"].Value?.ToString();
                var kaloritValue = dataGridView1.Rows[rivi].Cells["kalorit"].Value?.ToString();

                RuokaAine.maara = maaraValue;
                RuokaAine.kalorit = kaloritValue;

                double maara = double.Parse(RuokaAine.maara);
                double kalorit = double.Parse(RuokaAine.kalorit);
                double kokonaiskalori = ruokaaineet.LaskeKokonaiskalorit(maara, kalorit);
                TaulukonKalorit += kokonaiskalori;
                double joulet = ruokaaineet.Laskejoule(kokonaiskalori);
                TaulukonJoulet += joulet;
                dataGridView1.Rows[rivi].Cells["kokonaisjoulet"].Value = joulet.ToString("F2");
                dataGridView1.Rows[rivi].Cells["kokonaiskalori"].Value = kokonaiskalori.ToString("F2");

                int rowIndex = dataGridView1.Rows.Add();
                dataGridView1.Rows[rowIndex].Cells["nimi"].Value = "Total";
                dataGridView1.Rows[rowIndex].Cells["kokonaiskalori"].Value = TaulukonKalorit.ToString("F2");
                dataGridView1.Rows[rowIndex].Cells["kokonaisjoulet"].Value = TaulukonJoulet.ToString("F2");
            }
        }
    }
    public class ruokaaineet
    {
        public string nimi { get; set; }
        public string kalorit { get; set; }
        public string maara { get; set; }
        public static double Laskejoule(double kokonaiskalorit)
        {
                return kokonaiskalorit * 4.184;
        }

        public static double LaskeKokonaiskalorit(double maara, double kalorit)
        {
            return (maara/100) * kalorit;
        }
    }   
}
