﻿namespace Kaksiformia_käyttäjät
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNimi = new System.Windows.Forms.TextBox();
            this.txtSalasana = new System.Windows.Forms.TextBox();
            this.NimiL = new System.Windows.Forms.Label();
            this.SalasanaL = new System.Windows.Forms.Label();
            this.btnJatka = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNimi
            // 
            this.txtNimi.Location = new System.Drawing.Point(52, 62);
            this.txtNimi.Name = "txtNimi";
            this.txtNimi.Size = new System.Drawing.Size(100, 20);
            this.txtNimi.TabIndex = 0;
            // 
            // txtSalasana
            // 
            this.txtSalasana.Location = new System.Drawing.Point(52, 117);
            this.txtSalasana.Name = "txtSalasana";
            this.txtSalasana.Size = new System.Drawing.Size(100, 20);
            this.txtSalasana.TabIndex = 1;
            // 
            // NimiL
            // 
            this.NimiL.AutoSize = true;
            this.NimiL.Location = new System.Drawing.Point(52, 43);
            this.NimiL.Name = "NimiL";
            this.NimiL.Size = new System.Drawing.Size(27, 13);
            this.NimiL.TabIndex = 2;
            this.NimiL.Text = "Nimi";
            // 
            // SalasanaL
            // 
            this.SalasanaL.AutoSize = true;
            this.SalasanaL.Location = new System.Drawing.Point(52, 101);
            this.SalasanaL.Name = "SalasanaL";
            this.SalasanaL.Size = new System.Drawing.Size(51, 13);
            this.SalasanaL.TabIndex = 3;
            this.SalasanaL.Text = "Salasana";
            // 
            // btnJatka
            // 
            this.btnJatka.Location = new System.Drawing.Point(55, 155);
            this.btnJatka.Name = "btnJatka";
            this.btnJatka.Size = new System.Drawing.Size(75, 23);
            this.btnJatka.TabIndex = 4;
            this.btnJatka.Text = "Jatka";
            this.btnJatka.UseVisualStyleBackColor = true;
            this.btnJatka.Click += new System.EventHandler(this.btnJatka_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnJatka);
            this.Controls.Add(this.SalasanaL);
            this.Controls.Add(this.NimiL);
            this.Controls.Add(this.txtSalasana);
            this.Controls.Add(this.txtNimi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNimi;
        private System.Windows.Forms.TextBox txtSalasana;
        private System.Windows.Forms.Label NimiL;
        private System.Windows.Forms.Label SalasanaL;
        private System.Windows.Forms.Button btnJatka;
    }
}

