﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kaksiformia_käyttäjät
{
    public partial class Form1 : Form
    {
        private List<User> users;
        public Form1()
        {
            InitializeComponent();
            users = new List<User>
            {
                new User { Username = "Pekka", Password = "1234" },
                new User { Username = "Martti", Password = "5678" },
                new User { Username = "Pirkko", Password = "abcd" }
            };
        }

        private void btnJatka_Click(object sender, EventArgs e)
        {
            string Tunnus = txtNimi.Text;
            string salasana = txtSalasana.Text;

            User user = users.FirstOrDefault(users => users.Username == Tunnus && users.Password == salasana);
            if (user != null)
            {
                Form lomake2 = new Form2(txtNimi.Text);
                lomake2.ShowDialog();
            }
            else
            {
                MessageBox.Show("Tunnus tai salasana on väärin");
            }
        }
    }
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
