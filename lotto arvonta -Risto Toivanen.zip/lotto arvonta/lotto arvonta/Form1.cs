﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lotto_arvonta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {   
            txtLottorivi.Clear();
            Random random = new Random(); // random
            List <string> list = new List<string>();           // lottorivi lista
            try
            {
                for (int i = 0; i < 7; i++)                         // looppaa 7 kertaa
                {
                    list.Add(random.Next(1, 40).ToString() + Environment.NewLine);                   // arpoo luvun 1-40 
                }
                txtLottorivi.Text = string.Join("", list) ;         // printtaa listan
            }
            catch (Exception ex )
            {
                MessageBox.Show("" + ex.Message);           // error messages
            }
            
           


        }
    }
}
