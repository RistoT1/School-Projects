﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Painoindeksi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            VastausL.ForeColor = Color.Black;
            try
            {   
                double paino, pituus, vastaus;
                paino = double.Parse(txtPaino.Text);
                pituus = double.Parse(txtPituus.Text);

                vastaus = paino / (pituus * pituus) * 10000;
                VastausL.Text = string.Format("{0:F2} ", vastaus);
                
                if (vastaus < 17.9)
                {
                    indeksiL.Text = "alipaino";
                }
                else if (vastaus < 18.9 && vastaus > 17.9) 
                {
                    indeksiL.Text = "Lievä alipaino";
                }
                else if (vastaus > 24.9 && vastaus < 30)
                {
                    indeksiL.Text = "Lievä ylipaino";
                }
                else if (vastaus > 30)
                {
                    indeksiL.Text = "ylipaino";
                }
                else
                {
                    indeksiL.Text = "Normaalipaino";
                }
                
            }
            catch (Exception)
            {

                VastausL.Text = "Syötä numeroita";
                VastausL.ForeColor = Color.Red;
            }
            
        }
    }
}
