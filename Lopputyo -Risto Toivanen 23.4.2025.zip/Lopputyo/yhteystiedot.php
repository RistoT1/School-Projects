<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>yhteystiedot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Font Awesome 6 CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tYB3tP6KOa3F5ZuhyEPyehfiJ8aZjg5rZ9E+Kj+PB8p5h9bt" crossorigin="anonymous"></script>
</head>

<body>
    <?php include "nav.php" ?>
    <main> 
        <div class="container-fluid-yhteystiedot">
            <div class="col">
                <div class="neon-info-card">
                    <div class="glow"></div>
                    <div class="glow"></div>
                    <div class="neon-border"></div>

                    <div class="message-container">
                        <div class="messahe-header">
                            <h1>Lähetä viesti</h1>
                        </div>
                        <form class="contact-form" id="contactForm" action="viestilahetetty.php" method="post">
                            <div class="input-group">
                                <label for="name">nimi:</label>
                                <input type="text" id="name" name="name" placeholder="Syötä nimesi" required>
                            </div>

                            <div class="input-group">
                                <label for="email">Sähköposti:</label>
                                <input type="email" id="email" name="email" placeholder="Syötä sähköposti osoite" required>
                            </div>

                            <div class="input-group">
                                <label for="message">Viesti:</label>
                                <textarea id="message" name="message" placeholder="Viesti tähän..."
                                    required></textarea>
                            </div>

                            <input class="sendBtn" type="submit" id="sendBtn"></input>
                        </form>
                    </div>
                    <div class="yhteystiedot-container">
                        <h2 class="info-heading">yhteystiedot</h2>
                        <div class="neon-content-single" style="margin: 0px !important;">
                            <div style="display: flex; gap: 9rem; justify-content: center;">
                                <ul style="list-style: none; padding: 20px;">
                                    <li>
                                        <h5>Nimi</h5>
                                        <p>Risto Toivanen</p>
                                    </li>
                                    <li>
                                        <h5>Sähköposti</h5>
                                        <p>ristotoiv.rt@gmail.com</p>
                                    </li>
                                    <li>
                                        <h5>Puhelinnumero</h5>
                                        <p>0449787010</p>
                                    </li>
                                </ul>
                                <ul style="list-style: none; padding: 20px;">
                                    <li>
                                        <h5>Osoite</h5>
                                        <p>Huuhankatu xxx</p>
                                    </li>
                                    <li>
                                        <h5>Postitoimipaikka</h5>
                                        <p>70600</p>
                                    </li>
                                    <li>
                                        <h5>Kunta</h5>
                                        <p>Kuopio</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>
</body>

</html>