<nav>
    <div class="nav-container">
        <span class="navbar-name">RT</span>
        <div class="navbar-nav">
            <a class="navbar-link" href="paaverkkosivusto.php">Koti</a>
            <a class="navbar-link" href="yhteystiedot.php">Yhteystiedot</a>
        </div>
    </div>
</nav