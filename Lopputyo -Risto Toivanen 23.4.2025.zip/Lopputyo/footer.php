<footer class="footer" id="rivi6">
        <div class="footer-content">
            <div class="footer-section">
                <div class="footer-title">Risto Toivanen</div>
                <p>Olen Risto, opiskelen Savon ammattiopistossa tieto ja viestintä tekniikkaa. Pidän ohjelmoinnista ja
                    tykkään tehdä pieniä projekteja eri kielillä. Harrastan myös Jalkapalloa ja käyn aktiivisesti
                    kuntosalilla.</p>
                <div class="social-icons">
                </div>
            </div>

            <div class="footer-section">
                <div class="footer-title">Pikalinkit</div>
                <div class="footer-links">
                    <a href="#rivi1">etusivu</a>
                    <a href="#">yhteystiedot</a>
                    <a href="#rivi3">Kiinnostuksen kohteet</a>
                    <a href="#rivi4">ohjelmointitaidot</a>
                </div>
            </div>

            <div class="footer-section">
                <div class="footer-title">Ota yhteyttä</div>
                <p>Phone: 044 9787010</p>
                <p>Email: ristotoiv.rt@gmail.com</p>
                <button class="yhteystiedot-nappi"><span><a href="yhteystiedot.php">Ota yhteyttä!</a></span></button>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; Risto Toivanen 2025</p>
        </div>
    </footer>