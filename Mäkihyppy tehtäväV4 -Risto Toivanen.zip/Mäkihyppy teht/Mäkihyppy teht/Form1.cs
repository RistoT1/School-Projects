﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mäkihyppy_teht
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetCellTags();
            
            dataGridView1.RowsAdded += CheckRowCount;
        }

        private void CheckRowCount(object sender, EventArgs e)
        {
            // en ihan ymmärtänyt vielä.
            // Ensure we don't attempt to remove the "new row" (the row used for input)
            if (dataGridView1.Rows.Count >= 10)
            {
                // Check if the last row is the "new row" before removing it
                if (!dataGridView1.Rows[dataGridView1.Rows.Count - 1].IsNewRow)
                {
                    dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 1);  // Remove the last row
                }
                else
                {
                    MessageBox.Show("You can only add up to 10 rows.");
                }
            }
        }

        private void SetCellTags()
        {
            // Set the tags for the "Tuomari" columns
            for (int i = 9; i <= 13; i++)
            {
                dataGridView1.Columns[i].Tag = "Tuomari";
            }
            // Set the tags for the "Tuulikohta" columns
            for (int j = 2; j <= 6; j++)
            {
                dataGridView1.Columns[j].Tag = "Tuulikohta";
                Console.WriteLine("Set Tag for column " + j + " as Tuulikohta");  // Debugging print
            }
        }

        private void Jatka_Click(object sender, EventArgs e)
        {
            //listat
            List<double> TuomariPisteet = new List<double>(); // Lista Tuomarien antamista pisteistä
            List<double> Tuulikohdat = new List<double>(); // 

           bool ongelma = false; // ongelma tilanne

            //perusarvot
            double Kpiste = 0; // Kpiste
            double hypynPituus = 0; //hypyn pituus
            
            
            //tuomarien luvut eri muodoissa
            double TuomariParsed;   // tuomarin luku kun parsetettu
            double RoundedTuomari;  // pyötistetty tuomarin pisteet 0,5
           

            double TuulikohtaParsed;
            double keskiarvo = 0;
            double Tuulenvaikutus;

            //pisteet
            double KokonaisPisteet = 0; //Kokonaispisteet
            double RoundedKokonaisPisteet =0;
            double tyyliPisteet = 0;    // tuomarien antamat pisteet
            double hypynPituuspisteet = 0; // hypyn pituudesta saadut pisteet

            try
            {
                Kpiste = int.Parse(txtKpiste.Text); // parsettaa K pisteen
            }
            catch (Exception)
            {
                MessageBox.Show("syötä luku K-pisteeseen"); //virhe ilmotus
            }

            for (int rivi = 0; rivi < dataGridView1.RowCount -1; rivi++)   //joka rivin lukeminen
            {
                KokonaisPisteet = 0;            // nollaus
                tyyliPisteet = 0;
                hypynPituuspisteet = 0;
                TuomariPisteet.Clear();
                Tuulikohdat.Clear();

                if(ongelma)
                {
                    break;
                }

                foreach (DataGridViewCell cell in dataGridView1.Rows[rivi].Cells)
                {
                    if (cell.OwningColumn.Tag != null && cell.OwningColumn.Tag is string tag)
                    {
                        if (tag == "Tuomari")
                        {
                            if (double.TryParse(cell.Value?.ToString(), out TuomariParsed))
                            {
                                RoundedTuomari = Math.Round(TuomariParsed * 2, 0, MidpointRounding.AwayFromZero) / 2; // pyöristää luvun lähimpään 0,5
                                TuomariPisteet.Add(RoundedTuomari); // lisää pyöristetyn tuomari luvun pisteisiin
                            }
                        }
                        else if (tag == "Tuulikohta")
                        {
                            if (double.TryParse(cell.Value?.ToString(), out TuulikohtaParsed))
                            {
                                Tuulikohdat.Add(TuulikohtaParsed); // lisää pyöristetyn tuulikohta luvun pisteisiin 
                            }
                        }
                    }
                }


                keskiarvo = Tuulikohdat.Count > 0 ? Tuulikohdat.Average() : 0;

                Tuulenvaikutus = keskiarvo * (Kpiste - 36) / 20;
                //jos tuomari solu ei ole tyhjä ja parsettaa
                if (double.TryParse(dataGridView1.Rows[rivi].Cells[1].Value?.ToString(), out hypynPituus))
                {
                    hypynPituus += -Tuulenvaikutus;
                    if (hypynPituus >= Kpiste) //jos hypyn pituus on pitempi kuin K-piste, lisää hypynpituus pisteisiin 60 + yli metrit * 1,8 
                    {
                        hypynPituuspisteet = 60 + ((hypynPituus - Kpiste) * 1.8);
                    }
                    else if (hypynPituus < Kpiste) // jos alle K-pisteen vähentää 60 pisteestä vajaat metrit.
                    {
                        hypynPituuspisteet = 60 - ((Kpiste - hypynPituus) * 1.8);
                    }
                }
                if (hypynPituuspisteet < 0)
                {
                    hypynPituuspisteet = 0;
                }
                if (dataGridView1.Rows[rivi].Cells[0].Value != null && TuomariPisteet.Count >= 3)  // jos tuomareita on 3 tai yli niin suorittaa laskennan
                {
                    TuomariPisteet.Remove(TuomariPisteet.Max());    //poistaa Max
                    TuomariPisteet.Remove(TuomariPisteet.Min());    //poistaa Min
                    tyyliPisteet = TuomariPisteet.Sum();            // laskee yhteen summan
                }
                else if (dataGridView1.Rows[rivi].Cells[0].Value == null || TuomariPisteet.Count < 3)   // jos alle 3 tuomari ilmoittaa virhe ilmoituksen
                {
                    MessageBox.Show("tarvitaan Nimi ja vähintään 3 tuomaria");
                    ongelma = true;
                    continue; 
                }


                KokonaisPisteet = tyyliPisteet + hypynPituuspisteet; // laskee tuomari ja hyppypisteet yhteen
                RoundedKokonaisPisteet = Math.Round(KokonaisPisteet * 2, 0, MidpointRounding.AwayFromZero) / 2; // pyöristää luvun lähimpään 0,5

                dataGridView1.Rows[rivi].Cells[7].Value = keskiarvo.ToString();
                dataGridView1.Rows[rivi].Cells[8].Value = (Tuulenvaikutus * 1.8).ToString();
                dataGridView1.Rows[rivi].Cells[14].Value = hypynPituuspisteet.ToString();    //hypynpituus pisteet
                dataGridView1.Rows[rivi].Cells[15].Value = tyyliPisteet.ToString();          //Tuomarin pisteet
                dataGridView1.Rows[rivi].Cells[16].Value = RoundedKokonaisPisteet.ToString();       //Kokonaispisteet pisteet
                // Console.WriteLine(Kpiste.ToString() + " " + hypynPituus.ToString() + " " + hypynPituuspisteet.ToString()); // debugging printtaa piste arvot }

                
            }
         }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void KPisyteL_Click(object sender, EventArgs e)
        {

        }
    }
}
