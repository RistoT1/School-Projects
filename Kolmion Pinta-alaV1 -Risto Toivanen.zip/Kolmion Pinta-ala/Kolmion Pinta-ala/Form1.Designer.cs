﻿namespace Kolmion_Pinta_ala
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Kanta = new System.Windows.Forms.Label();
            this.Korkeus = new System.Windows.Forms.Label();
            this.txtKanta = new System.Windows.Forms.TextBox();
            this.txtKorkeus = new System.Windows.Forms.TextBox();
            this.jakotext = new System.Windows.Forms.Label();
            this.Kertotext = new System.Windows.Forms.Label();
            this.VastausL = new System.Windows.Forms.Label();
            this.Laske = new System.Windows.Forms.Button();
            this.kolmio = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Kanta
            // 
            this.Kanta.AutoSize = true;
            this.Kanta.Location = new System.Drawing.Point(100, 54);
            this.Kanta.Name = "Kanta";
            this.Kanta.Size = new System.Drawing.Size(51, 20);
            this.Kanta.TabIndex = 0;
            this.Kanta.Text = "Kanta";
            // 
            // Korkeus
            // 
            this.Korkeus.AutoSize = true;
            this.Korkeus.Location = new System.Drawing.Point(224, 54);
            this.Korkeus.Name = "Korkeus";
            this.Korkeus.Size = new System.Drawing.Size(67, 20);
            this.Korkeus.TabIndex = 1;
            this.Korkeus.Text = "Korkeus";
            // 
            // txtKanta
            // 
            this.txtKanta.Location = new System.Drawing.Point(82, 94);
            this.txtKanta.Name = "txtKanta";
            this.txtKanta.Size = new System.Drawing.Size(100, 26);
            this.txtKanta.TabIndex = 2;
            // 
            // txtKorkeus
            // 
            this.txtKorkeus.Location = new System.Drawing.Point(206, 94);
            this.txtKorkeus.Name = "txtKorkeus";
            this.txtKorkeus.Size = new System.Drawing.Size(100, 26);
            this.txtKorkeus.TabIndex = 3;
            // 
            // jakotext
            // 
            this.jakotext.AutoSize = true;
            this.jakotext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.jakotext.Location = new System.Drawing.Point(312, 95);
            this.jakotext.Name = "jakotext";
            this.jakotext.Size = new System.Drawing.Size(25, 22);
            this.jakotext.TabIndex = 4;
            this.jakotext.Text = "/2";
            // 
            // Kertotext
            // 
            this.Kertotext.AutoSize = true;
            this.Kertotext.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Kertotext.Location = new System.Drawing.Point(186, 98);
            this.Kertotext.Name = "Kertotext";
            this.Kertotext.Size = new System.Drawing.Size(20, 25);
            this.Kertotext.TabIndex = 5;
            this.Kertotext.Text = "*";
            // 
            // VastausL
            // 
            this.VastausL.AutoSize = true;
            this.VastausL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.VastausL.Location = new System.Drawing.Point(202, 135);
            this.VastausL.Name = "VastausL";
            this.VastausL.Size = new System.Drawing.Size(28, 22);
            this.VastausL.TabIndex = 6;
            this.VastausL.Text = "---";
            // 
            // Laske
            // 
            this.Laske.Location = new System.Drawing.Point(82, 134);
            this.Laske.Name = "Laske";
            this.Laske.Size = new System.Drawing.Size(100, 33);
            this.Laske.TabIndex = 7;
            this.Laske.Text = "Laske";
            this.Laske.UseVisualStyleBackColor = true;
            this.Laske.Click += new System.EventHandler(this.Laske_Click);
            // 
            // kolmio
            // 
            this.kolmio.AutoSize = true;
            this.kolmio.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F);
            this.kolmio.Location = new System.Drawing.Point(410, 64);
            this.kolmio.Name = "kolmio";
            this.kolmio.Size = new System.Drawing.Size(143, 135);
            this.kolmio.TabIndex = 8;
            this.kolmio.Text = "▲";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label1.Location = new System.Drawing.Point(468, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 22);
            this.label1.TabIndex = 9;
            this.label1.Text = "Kanta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label2.ForeColor = System.Drawing.Color.Coral;
            this.label2.Location = new System.Drawing.Point(468, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "|";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label3.ForeColor = System.Drawing.Color.Coral;
            this.label3.Location = new System.Drawing.Point(468, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 22);
            this.label3.TabIndex = 11;
            this.label3.Text = "|";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label4.ForeColor = System.Drawing.Color.Coral;
            this.label4.Location = new System.Drawing.Point(468, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 22);
            this.label4.TabIndex = 12;
            this.label4.Text = "|";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.ForeColor = System.Drawing.Color.Coral;
            this.label5.Location = new System.Drawing.Point(489, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 22);
            this.label5.TabIndex = 13;
            this.label5.Text = "Korkeus";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kolmio);
            this.Controls.Add(this.Laske);
            this.Controls.Add(this.VastausL);
            this.Controls.Add(this.Kertotext);
            this.Controls.Add(this.jakotext);
            this.Controls.Add(this.txtKorkeus);
            this.Controls.Add(this.txtKanta);
            this.Controls.Add(this.Korkeus);
            this.Controls.Add(this.Kanta);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Kanta;
        private System.Windows.Forms.Label Korkeus;
        private System.Windows.Forms.TextBox txtKanta;
        private System.Windows.Forms.TextBox txtKorkeus;
        private System.Windows.Forms.Label jakotext;
        private System.Windows.Forms.Label Kertotext;
        private System.Windows.Forms.Label VastausL;
        private System.Windows.Forms.Button Laske;
        private System.Windows.Forms.Label kolmio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

