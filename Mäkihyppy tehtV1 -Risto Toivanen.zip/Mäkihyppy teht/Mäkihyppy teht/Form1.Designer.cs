﻿namespace Mäkihyppy_teht
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Jatka = new System.Windows.Forms.Button();
            this.Hyppääjä = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Virheetonhyppy = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Alastulo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Loppuliuku = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ilmalento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tuomari1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tuomari2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tuomari3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tuomari4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tuomari5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tyylipisteet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KokonaisPisteet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Hyppääjä,
            this.Virheetonhyppy,
            this.Alastulo,
            this.Loppuliuku,
            this.Ilmalento,
            this.Tuomari1,
            this.Tuomari2,
            this.Tuomari3,
            this.Tuomari4,
            this.Tuomari5,
            this.Tyylipisteet,
            this.KokonaisPisteet});
            this.dataGridView1.Location = new System.Drawing.Point(30, 90);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(2027, 150);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Jatka
            // 
            this.Jatka.Location = new System.Drawing.Point(1917, 246);
            this.Jatka.Name = "Jatka";
            this.Jatka.Size = new System.Drawing.Size(102, 49);
            this.Jatka.TabIndex = 3;
            this.Jatka.Text = "Jatka";
            this.Jatka.UseVisualStyleBackColor = true;
            this.Jatka.Click += new System.EventHandler(this.Jatka_Click);
            // 
            // Hyppääjä
            // 
            this.Hyppääjä.HeaderText = "hyppaaja";
            this.Hyppääjä.MinimumWidth = 8;
            this.Hyppääjä.Name = "Hyppääjä";
            // 
            // Virheetonhyppy
            // 
            this.Virheetonhyppy.HeaderText = "Virheetönhyppy";
            this.Virheetonhyppy.MinimumWidth = 8;
            this.Virheetonhyppy.Name = "Virheetonhyppy";
            this.Virheetonhyppy.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Virheetonhyppy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Alastulo
            // 
            this.Alastulo.HeaderText = "Alastulo";
            this.Alastulo.MinimumWidth = 8;
            this.Alastulo.Name = "Alastulo";
            // 
            // Loppuliuku
            // 
            this.Loppuliuku.HeaderText = "Loppuliuku";
            this.Loppuliuku.MinimumWidth = 8;
            this.Loppuliuku.Name = "Loppuliuku";
            // 
            // Ilmalento
            // 
            this.Ilmalento.HeaderText = "Ilmalento";
            this.Ilmalento.MinimumWidth = 8;
            this.Ilmalento.Name = "Ilmalento";
            // 
            // Tuomari1
            // 
            this.Tuomari1.HeaderText = "Tuomari1";
            this.Tuomari1.MinimumWidth = 8;
            this.Tuomari1.Name = "Tuomari1";
            // 
            // Tuomari2
            // 
            this.Tuomari2.HeaderText = "Tuomari2";
            this.Tuomari2.MinimumWidth = 8;
            this.Tuomari2.Name = "Tuomari2";
            // 
            // Tuomari3
            // 
            this.Tuomari3.HeaderText = "Tuomari3";
            this.Tuomari3.MinimumWidth = 8;
            this.Tuomari3.Name = "Tuomari3";
            // 
            // Tuomari4
            // 
            this.Tuomari4.HeaderText = "Tuomari4";
            this.Tuomari4.MinimumWidth = 8;
            this.Tuomari4.Name = "Tuomari4";
            // 
            // Tuomari5
            // 
            this.Tuomari5.HeaderText = "Tuomari5";
            this.Tuomari5.MinimumWidth = 8;
            this.Tuomari5.Name = "Tuomari5";
            // 
            // Tyylipisteet
            // 
            this.Tyylipisteet.HeaderText = "Tyylipisteet";
            this.Tyylipisteet.MinimumWidth = 8;
            this.Tyylipisteet.Name = "Tyylipisteet";
            this.Tyylipisteet.ReadOnly = true;
            // 
            // KokonaisPisteet
            // 
            this.KokonaisPisteet.HeaderText = "KokonaisPisteet";
            this.KokonaisPisteet.MinimumWidth = 8;
            this.KokonaisPisteet.Name = "KokonaisPisteet";
            this.KokonaisPisteet.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2297, 450);
            this.Controls.Add(this.Jatka);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Jatka;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hyppääjä;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Virheetonhyppy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Alastulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Loppuliuku;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ilmalento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tuomari1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tuomari2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tuomari3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tuomari4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tuomari5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tyylipisteet;
        private System.Windows.Forms.DataGridViewTextBoxColumn KokonaisPisteet;
    }
}

