﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mäkihyppy_teht
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Jatka_Click(object sender, EventArgs e)
        {
            
            List<double> temp = new List<double>();
            int Lisapisteet;
            double parsedvalue;
            double KokonaisPisteet = 0;
            double tyyliPisteet = 0;

            //periaatteessa check box on täysin turha mut sentään opin
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DataGridViewCheckBoxCell chk = new DataGridViewCheckBoxCell();
                if (chk.Selected == true)
                {
                    Lisapisteet = 60;
                }
            }

            for (int rivi = 0; rivi < dataGridView1.RowCount; rivi++)
            {
                KokonaisPisteet = 0;
                tyyliPisteet = 0;
                temp.Clear();
                for (int solu = 5; solu < 10; solu++)
                {
                    if (dataGridView1.Rows[rivi].Cells[solu].Value == null)
                    {
                        continue;
                    }

                    if(double.TryParse(dataGridView1.Rows[rivi].Cells[solu].Value.ToString(),out parsedvalue))
                    {
                        double roundedValue = Math.Round(parsedvalue * 2, 0, MidpointRounding.AwayFromZero) / 2;
                        temp.Add(roundedValue);
                    }
                    
                    
                }
                
                if (temp.Count >= 3)
                {
                    temp.Remove(temp.Max());
                    temp.Remove(temp.Min());
                    tyyliPisteet = temp.Sum();
                }
                else if (dataGridView1.Rows[rivi].Cells[0].Value != null && temp.Count < 3)
                {
                    MessageBox.Show("tarvitaan vähintään 3 tuomaria");
                    break;
                }
                KokonaisPisteet = tyyliPisteet;
                dataGridView1.Rows[rivi].Cells[10].Value = tyyliPisteet.ToString();
                dataGridView1.Rows[rivi].Cells[11].Value = KokonaisPisteet.ToString();
                

            }
            
           

            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
