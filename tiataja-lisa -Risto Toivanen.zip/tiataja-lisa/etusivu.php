<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>

<body>
    <!--include header-->
    <?php include"header.php"; ?>
    <main>
        <div class="container">
            <div class="quote-container">
                <div class="quote">
                    <p>Tuoretta lähiruokaa suoraan kotiovellesi!</p>
                </div>
                <div class="small-quote">
                    <p>Tuottajamarket - Kaupunkilaisille vaivatonta lähiruoan hankintaa.</p>
                </div>
                <div class="link">
                    <a href="">Selaa tuotteita</a>
                </div>
            </div>
            <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 315
                " xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150">
                <path
                    d="M 0,600 L 0,300 C 102.03571428571428,315.19642857142856 204.07142857142856,330.3928571428571 338,283 C 471.92857142857144,235.60714285714286 637.75,125.62499999999997 768,115 C 898.25,104.37500000000003 992.9285714285713,193.10714285714286 1099,203 C 1205.0714285714287,212.89285714285714 1322.5357142857142,143.94642857142856 1440,75 L 1440,600 L 0,600 Z"
                    stroke="none" stroke-width="0" fill="#ffffff" fill-opacity="1"
                    class="transition-all duration-300 ease-in-out delay-150 path-0"></path>
            </svg>
        </div>
        <div class="info-container">
            <h1>Kuinka Se Toimii</h1>
            <div class="steps">
                <div class="step-1 step">
                    <div class="icon-container">
                        <i class="fa-solid fa-pen"></i>
                    </div>
                    <div class="title">
                        <h3>1. Rekisteröityminen</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Aloita rekisteröitymällä Tuottajamarket-
                            verkkopalveluun omalla
                            käyttäjätunnuksellasi ja salasanallasi.
                        </p>
                    </div>
                </div>
                <div class="step-2 step">
                    <div class="icon-container">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                    <div class="title">
                        <h3>2. selaa tuotteita</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Kirjauduttuasi sisään voit selata monipuolista valikoimaa laadukkaita ja lähellä tuotettuja
                            tuotteita. Käy läpi eri tuotekategorioita ja tutustu tarjontaan.
                        </p>
                    </div>
                </div>
                <div class="step-3 step">
                    <div class="icon-container">
                        <i class="fa-solid fa-plus"></i>
                    </div>
                    <div class="title">
                        <h3>3. lisää ostoskoriin</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Valittuasi haluamasi tuotteet voit lisätä ne ostoskoriin. Voit valita useita tuotteita eri
                            kategorioista.
                        </p>
                    </div>
                </div>
                <div class="step-4 step">
                    <div class="icon-container">
                        <i class="fa-regular fa-face-smile"></i>
                    </div>
                    <div class="title">
                        <h3>4. Tarkista ostokset</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Siirry ostoskoriin ja tarkista valintasi ennen tilauksen vahvistamista. Voit muuttaa määriä
                            tai poistaa tuotteita tarvittaessa.
                        </p>
                    </div>
                </div>
                <div class="step-5 step">
                    <div class="icon-container">
                        <i class="fa-regular fa-thumbs-up"></i>
                    </div>
                    <div class="title">
                        <h3>5. Tilauksen vahvistus</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Kun olet tyytyväinen ostoskoriisi, vahvista tilauksesi ja syötä tarvittavat
                            toimitustiedot
                        </p>
                    </div>
                </div>
                <div class="step-6 step">
                    <div class="icon-container">
                        <i class="fa-solid fa-gift"></i>
                    </div>
                    <div class="title">
                        <h3>6. Toimitus kotiovellesi</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Odota tuotteiden saapumista kotiovellesi. Tuottajamarket-verkkopalvelu toimittaa laadukkaat
                            lähiruokatuotteet
                            vaivattomasti sinulle.
                        </p>
                    </div>
                </div>
                <div class="step-7 step">
                    <div class="icon-container">
                        <i class="fa-regular fa-heart"></i>
                    </div>
                    <div class="title">
                        <h3>7. Nauti lähiruoasta</h3>
                    </div>
                    <div class="subtitle">
                        <p>
                            Saapuneet tuotteet ovat nyt valmiita
                            nautittavaksi. Nauti herkullisista ja
                            laadukkaista lähiruoista omassa arjessasi!
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include"footer.php"; ?>
</body>

</html>