<header>
        <nav>
            <div class="nav-container">
                <div class="logo">
                    <h1>LOGO</h1>
                </div>
                <div class="nav-link">
                    <a href="">Kauppaan >></a>
                </div>
            </div>
        </nav>
</header>