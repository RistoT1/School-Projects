<footer>
        <div class="footer-container">
            <h3>(C) TAITAJA 2024</h3>
            <div class="footer-text">
                <p>Risto Toivanen</p>
                <p>Savon ammattikoulu</p>
            </div>
        </div>    
</footer> 