﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palkanlasku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Laske_Click(object sender, EventArgs e)
        {
           
            double x, y, z, i, tulo = 0, tunnit = 0;

            bool isparced = Double.TryParse(txtTunti.Text, out x);      // Tuntipalkka
            Double.TryParse(txtnorm.Text, out y);                       // Normaali tuntipalkka
            Double.TryParse(txtpuol.Text, out z);                       // 50% korko tuntipalkka
            Double.TryParse(txtsata.Text, out i);                       // 100% korko Tuntipalkka

            if (isparced ) { 
                tulo = (y + z * 1.5 + i * 2);                           //Laskee kokonaispalkan
                tunnit = (y + z + i);                                   //Laskee Tunnit
                TunnitL.Text = tunnit.ToString();       
                PalkkaL.Text = tulo.ToString() + "€";                   //converttaa stringit

            }
            
            else
            {
                MessageBox.Show("syötä Tuntipalkka!" );       //error message jos tuntipalkkassa ei ole lukua
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
