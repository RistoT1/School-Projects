﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palkanlasku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Laske_Click(object sender, EventArgs e)
        {
           
            double x, y, z, i, tulo = 0;
            bool isparced = Double.TryParse(txtTunti.Text, out x);
            Double.TryParse(txtnorm.Text, out y);
            Double.TryParse(txtpuol.Text, out z);
            Double.TryParse(txtsata.Text, out i);

            if (isparced ) { 
                if (y > 0)
                {
                    tulo = y * x;
                }
                if (z > 0)
                {
                    tulo += x * 1.5 * z;
                }
                if (i > 0)
                {
                    tulo += x * 2 * i;
                }

                MessageBox.Show(tulo.ToString() + "€");
            }
            
            else
            {
                MessageBox.Show("syötä tarvittavat luvut!" );
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
